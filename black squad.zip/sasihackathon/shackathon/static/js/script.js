// You can add JS logic to enhance the interactivity of the app
console.log('Fake Review Detector Loaded');
