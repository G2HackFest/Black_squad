from flask import Flask, request, render_template
import joblib
import pandas as pd
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import time

# Initialize Flask app
app = Flask(__name__)


# Load trained model and vectorizer
model = joblib.load('C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\model\\fake_review_model.pkl')
vectorizer = joblib.load('C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\model\\tfidf_vectorizer.pkl')

# Configure Selenium options
chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--disable-gpu')
chrome_options.add_argument('--no-sandbox')

# Path to your chromedriver.exe
CHROME_DRIVER_PATH = "C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\chromedriver.exe"  # Update this path!

# URL to extract reviews
def extract_reviews(url):
    reviews_list = []

    # Set up the WebDriver
    service = Service(CHROME_DRIVER_PATH)
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        driver.get(url)
        time.sleep(5)  # Give page time to load

        # Extract page content
        soup = BeautifulSoup(driver.page_source, 'html.parser')

        # Identify reviews based on website structure
        # For Amazon
        if "amazon" in url:
            reviews = soup.find_all('span', {'data-hook': 'review-body'})
        # For Flipkart
        elif "flipkart" in url:
            reviews = soup.find_all('div', {'class': 't-ZTKy'})
        # For Walmart
        elif "walmart" in url:
            reviews = soup.find_all('span', {'class': 'review-text'})
        # For eBay
        elif "ebay" in url:
            reviews = soup.find_all('div', {'class': 'review-item-content'})

        # Extract and store reviews
        for review in reviews:
            reviews_list.append(review.get_text().strip())

    except Exception as e:
        print(f"Error occurred while extracting reviews: {e}")
    finally:
        driver.quit()

    return reviews_list


# Home Page
@app.route('/')
def home():
    return render_template('index.html')


# Process URL and classify reviews
@app.route('/check', methods=['POST'])
def check():
    url = request.form['url']
    reviews = extract_reviews(url)

    if not reviews:
        return render_template('result.html', error="❌ No reviews found or invalid URL!")

    # Vectorize and predict
    review_vectors = vectorizer.transform(reviews)
    predictions = model.predict(review_vectors)

    # Format results
    results = [{'review': review, 'label': 'Fake' if pred == 1 else 'Genuine'} for review, pred in zip(reviews, predictions)]
    return render_template('result.html', results=results, url=url)


if __name__ == '__main__':
    app.run(debug=True)
