# Import required libraries
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
import joblib

# Load dataset
df_fake = pd.read_csv('C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\data\\fake_reviews.csv')
df_genuine = pd.read_csv('C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\data\\genuine_reviews.csv')

# Combine data and assign labels
df_fake['label'] = 1  # Fake
df_genuine['label'] = 0  # Genuine
df = pd.concat([df_fake, df_genuine], ignore_index=True)

# Prepare features and labels
X = df['review_text']
y = df['label']

# TF-IDF Vectorization
vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
X_tfidf = vectorizer.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_tfidf, y, test_size=0.3, random_state=42)

# Train model using Naive Bayes
model = MultinomialNB()
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
print(f"Model Accuracy: {accuracy_score(y_test, y_pred) * 100:.2f}%")

# Save model and vectorizer
joblib.dump(model, 'C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\model\\fake_review_model.pkl')
joblib.dump(vectorizer, 'C:\\Users\\sasir\\Desktop\\sasihackathon\\shackathon\\model/tfidf_vectorizer.pkl')
