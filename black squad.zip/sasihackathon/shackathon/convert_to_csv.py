import os
import pandas as pd

# Set the correct path to the op_spam_v1.4 dataset
dataset_path = "C:\\Users\\kyle2\\Downloads\\op_spam_v1.4\\op_spam_v1.4"

# Define output paths
output_csv_fake = "data/fake_reviews.csv"
output_csv_genuine = "data/genuine_reviews.csv"

# Create lists to store data
fake_reviews = []
genuine_reviews = []


# Function to load reviews from folders
def load_reviews(folder_path, label):
    reviews = []
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            # Check for .txt or .TXT files
            if file.endswith(".txt") or file.endswith(".TXT"):
                file_path = os.path.join(root, file)
                print(f"✅ Reading: {file_path}")  # Debug output
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        review_text = f.read().strip()
                        # Skip empty reviews
                        if review_text:
                            reviews.append({"review_text": review_text, "label": label})
                        else:
                            print(f"⚠️ Empty file skipped: {file_path}")
                except Exception as e:
                    print(f"❌ Error reading {file_path}: {e}")
    return reviews


# Load Fake Reviews
fake_reviews += load_reviews(os.path.join(dataset_path, "positive_polarity/deceptive_from_MTurk"), 1)
fake_reviews += load_reviews(os.path.join(dataset_path, "negative_polarity/deceptive_from_MTurk"), 1)

# Load Genuine Reviews
genuine_reviews += load_reviews(os.path.join(dataset_path, "positive_polarity/truthful_from_Web"), 0)
genuine_reviews += load_reviews(os.path.join(dataset_path, "negative_polarity/truthful_from_Web"), 0)

# Convert to DataFrame and save as CSV
df_fake = pd.DataFrame(fake_reviews)
df_genuine = pd.DataFrame(genuine_reviews)

# Debug: Show a sample of the data
print(f"\n📊 Sample Fake Reviews:\n{df_fake.head()}")
print(f"\n📊 Sample Genuine Reviews:\n{df_genuine.head()}")

# Check if DataFrame is empty
if df_fake.empty or df_genuine.empty:
    print("❌ Error: No reviews were found! Check the dataset path or file structure.")
else:
    # Create data folder if it does not exist
    if not os.path.exists("data"):
        os.makedirs("data")

    # Save to CSV
    df_fake.to_csv(output_csv_fake, index=False)
    df_genuine.to_csv(output_csv_genuine, index=False)

    print(f"\n✅ Fake reviews saved to: {output_csv_fake}")
    print(f"✅ Genuine reviews saved to: {output_csv_genuine}")
